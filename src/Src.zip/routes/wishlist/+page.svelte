<script>
	import Item from "$lib/components/Item.svelte";

	let { data } = $props();

	let wishlistProducts = $derived(
		data.products.filter((p) => {
			let found = false;
			data.wishlist.forEach((w) => {
				if (w.product_id == p.id) {
					found = true;
				}
				return found;
			});
		}),
	);
</script>

<section>
	<div class="items-container">
		{#each wishlistProducts as i}
			<Item item={i} />
		{/each}
	</div>
</section>

<style lang="postcss">
	@import "$lib/theme.css";

	.items-container {
		@apply w-full min-h-(--main-size) p-5
		grid auto-rows-fr grid-cols-12 gap-5;
	}
</style>

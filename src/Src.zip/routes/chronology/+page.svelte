<script>
	import Item from "$lib/components/Item.svelte";

	let { data } = $props();

	let chronologyProducts = $derived(
		data.products.filter((p) => {
			let found = false;
			data.chronology.forEach((c) => {
				if (c.product_id == p.id) {
					found = true;
				}
				return found;
			});
		}),
	);
</script>

<section>
	<div class="items-container">
		{#each chronologyProducts as i}
			<Item item={i} />
		{/each}
	</div>
</section>

<style lang="postcss">
	@import "$lib/theme.css";

	.items-container {
		@apply w-full min-h-(--main-size) p-5
		grid auto-rows-fr grid-cols-12 gap-5;
	}
</style>

import "$lib/supabase";

<script>
	import blankIcon from "$lib/assets/blankuser.svg";
</script>

<a href="/profile" class="h-full aspect-square border rounded-full">
	<img src={blankIcon} alt="User Icon" class="w-full h-full rounded-full" />
</a>

<script lang="ts">
	import { addToCart } from "$lib/cart";
	import { addToWishlist } from "$lib/wishlist";

	import Carousel from "$lib/components/Carousel.svelte";

	let { data } = $props();

	let item = $derived(data.products?.find((i) => i.id == data.itemId));
</script>

<!------------------------------------------>

<svelte:head>
	<title>{item.name} - Rolling Emporium</title>
</svelte:head>

<!------------------------------------------>

<section class="item-info">
	<Carousel imgs={item.images} alt="Images of {item.name}" />

	<div class="item-specifics">
		<h1>{item.name}</h1>
		<p>{item.description}</p>

		{#if data.user}
			<div class="item-cost">
				<p class="price-tag">
					{item.cost - item.cost * (item.discount ?? 0)} €
				</p>
				<button class="std-btn" onclick={addToCart}>Add To Cart</button>
			</div>
			<button class="std-btn w-full" onclick={addToWishlist}>
				Add To Wishlist
			</button>
		{:else}
			<p class="price-tag">
				{item.cost - item.cost * (item.discount ?? 0)} €
			</p>
		{/if}
	</div>
</section>

<!------------------------------------------>

<style lang="postcss">
	@import "$lib/theme.css";

	.item-info {
		@apply page
		flex justify-around items-start flex-col md:flex-row;
	}
	.item-specifics {
		@apply w-full md:w-1/2 gap-5
		flex flex-col justify-start items-start;
	}
	.item-cost {
		@apply w-full h-fit
		flex flex-row justify-between;
	}
</style>
